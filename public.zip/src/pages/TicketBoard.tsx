// src/pages/TicketBoard.tsx
"use client";
import React, { useEffect, useRef, useState } from "react";
import { Grid, Paper, Divider } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import { monitorForElements } from "@atlaskit/pragmatic-drag-and-drop/element/adapter";

import defaultTasks from "../../Tasks";
import type { BoardColumn, Ticket } from "src/types/type";
import { ColumnHeader } from "../components/ColumnHeader";
import { ColumnList } from "../components/ColumnList";
import { ColumnFooter } from "../components/ColumnFooter";

const useStyles = makeStyles((theme) => ({
  root: { display: "flex", height: "100%" },
  callWrap: {
    display: "flex",
    flex: "1 1 auto",
    flexWrap: "nowrap",
    overflowX: "auto",
    overflowY: "hidden",
    height: "93.6vh",
    scrollbarWidth: "thin",
  },
  boardCard: {
    width: 380,
    margin: "0 8px",
    flexShrink: 0,
    display: "flex",
    height: "99%",
    flexDirection: "column",
    [theme.breakpoints.down("sm")]: { width: 300 },
  },
  divider: { marginTop: theme.spacing(2) },
}));
export const TicketBoard: React.FC = () => {
  const classes = useStyles();
  // agora é um array de colunas
  const [columns, setColumns] = useState<BoardColumn[]>(defaultTasks.data);

  // ref pra sempre ler o estado atual dentro do monitor
  const colsRef = useRef(columns);
  useEffect(() => {
    colsRef.current = columns;
  }, [columns]);

  // função auxiliar para achar índice da coluna que contém um ticket
  const findColumnIdx = (ticketId: string) =>
    colsRef.current.findIndex((col) =>
      col.tickets.some((t) => t.id === ticketId)
    );

  useEffect(() => {
    const unsubscribe = monitorForElements({
      onDrop({ source, location }) {
        const data = source.data as { itemId: string; type: string };
        if (data.type !== "ticket") return;

        const ticketId = data.itemId;
        const cols = [...colsRef.current];

        // onde soltei → procurar dropTarget com insertIndex
        const dropTargets = location.current?.dropTargets || [];
        const dropData = dropTargets.find((t) => t.data.insertIndex != null);
        if (!dropData) return;
        const toColId = dropData.data.dropTargetFor as string;
        let insertIndex = dropData.data.insertIndex as number;

        const fromIdx = findColumnIdx(ticketId);
        if (fromIdx < 0) return;
        const fromCol = cols[fromIdx];

        const toIdx = cols.findIndex((c) => c.id === toColId);
        if (toIdx < 0) return;
        const toCol = cols[toIdx];

        // remove do origin
        const origList = [...fromCol.tickets];
        const origIdx = origList.findIndex((t) => t.id === ticketId);
        if (origIdx < 0) return;
        const [moved] = origList.splice(origIdx, 1);

        // ajusta índice se mesma coluna
        if (fromIdx === toIdx && origIdx < insertIndex) insertIndex--;
        insertIndex = Math.max(0, Math.min(insertIndex, origList.length));

        // aborta se não mudou
        if (fromIdx === toIdx && origIdx === insertIndex) return;

        // insere na lista de destino
        const newToList =
          fromIdx === toIdx ? [...origList] : [...toCol.tickets];
        newToList.splice(insertIndex, 0, moved);

        // atualiza estado
        cols[fromIdx] = { ...fromCol, tickets: origList };
        cols[toIdx] = { ...toCol, tickets: newToList };

        setColumns(cols);
      },
    });
    return () => unsubscribe();
  }, []);

  return (
    <Grid container className={classes.root}>
      <Grid container wrap="nowrap" className={classes.callWrap}>
        {columns.map((col) => (
          <Paper key={col.id} elevation={1} className={classes.boardCard}>
            <ColumnHeader title={col.name} />
            <Divider />
            <ColumnList calls={col.tickets} columnKey={col.id} />
            <Divider className={classes.divider} />
            <ColumnFooter />
          </Paper>
        ))}
      </Grid>
    </Grid>
  );
};
