// src/components/ColumnList.tsx
import React from "react";
import { Grid, makeStyles } from "@material-ui/core";
import { Column } from "./Column";
import type { Ticket } from "src/types/type";

const useStyles = makeStyles(() => ({
  columnContent: {
    flex: 1,
    overflowY: "auto",
    height: "100%",
    padding: 8,
    scrollbarWidth: "thin",
  },
}));

interface ColumnListProps {
  calls: Ticket[];
  columnKey: string;
}

export const ColumnList: React.FC<ColumnListProps> = ({ calls, columnKey }) => {
  const classes = useStyles();
  return (
    <Grid container spacing={1} className={classes.columnContent}>
      {calls.map((ticket) => (
        <Grid key={ticket.id} item xs={12}>
          <Column ticket={ticket} />
        </Grid>
      ))}
    </Grid>
  );
};
