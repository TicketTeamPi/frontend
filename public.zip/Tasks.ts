// src/Tasks.ts
import type { BoardResponse } from "src/types/type";

const defaultTasks: BoardResponse = {
  data: [
    {
      id: "170b5149-9657-428c-8b5c-dda2b3b0b870",
      name: "Dev Ready",
      tickets: [
        {
          id: "32db0daf-f5b0-4dbd-a378-82adac4d41aa",
          title: "Primeira Chamada",
          priority: null,
          userId: "2fec15dd-0532-4670-9444-183e6662fc5e",
          responsibleId: null,
          sector: {
            name: "Setor um",
            color: "#1D1D17",
          },
        },
      ],
    },
    {
      id: "8ad95406-0d6f-46e8-b4f6-390aec5b2da8",
      name: "On Going",
      tickets: [],
    },
  ],
};

export default defaultTasks;
